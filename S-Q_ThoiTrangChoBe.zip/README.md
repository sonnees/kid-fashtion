# S-Q_ThoiTrangChoBe
Project chủ đề "Shop bán quần áo trẻ em" 
Link: 

Mã đề tài: 05
| STT | MSSV  | Họ tên |
| :--:   | :--: | :----: |
| null | 20049891 | Nguyễn Văn Sơn |
| null | 200448861 | Nguyễn Văn Quý |
